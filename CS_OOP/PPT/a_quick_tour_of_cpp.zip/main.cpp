#include <cmath>
#include <iostream>
#include "xchen_algorithm.h"
const double PI = 3.14;

struct Student {
  int id;
  std::string name;
};

bool operator<(const Student& s1, const Student& s2)
{
  return s1.id < s2.id;
}

std::ostream& operator<<(std::ostream& out, const Student& s)
{
  out << "(" << s.id << "," << s.name << ")";
  return out;
}

class Shape {
protected:
  double area, perimeter;
public:
  virtual ~Shape() {}
  double get_area() const { return area; }
  double get_perimeter() const { return perimeter; }
  virtual std::string name() const = 0;
  virtual void calc_area() = 0;
  virtual void calc_perimeter() = 0;
  // friend std::ostream& operator<<(std::ostream&, const Shape&);
};

std::ostream& operator<<(std::ostream& out, const Shape& s)
{
  out << "(" << s.name() << ": " << s.get_area() << "," << s.get_perimeter() << ")";
  return out;
}

bool less_shape_area(Shape* s1, Shape* s2) {
  return s1->get_area() < s2->get_area();
}

bool less_shape_perimeter(Shape* s1, Shape* s2) {
  return s1->get_perimeter() < s2->get_perimeter();
}

bool greater_shape_area(Shape* s1, Shape* s2) {
  return s1->get_area() > s2->get_area();
}

class Rectangle: public Shape {
private:
  double w, h;
public:
  Rectangle(double w, double h) : w(w), h(h) {}
  std::string name() const override {
    return "Rectangle";
  }
  void calc_area() override {
    area = w * h;
  }
  void calc_perimeter() override {
    perimeter = 2 * (w + h);
  }
};

class Circle: public Shape {
private:
  double r;
public:
  Circle(double r) : r(r) {}
  std::string name() const override {
    return "Circle";
  }
  void calc_area() override {
    area = PI * r * r;
  }
  void calc_perimeter() override {
    perimeter = 2 * PI * r;
  }
};

class Triangle: public Shape {
private:
  double a, b, c;
public:
  Triangle(double a, double b, double c) : a(a), b(b), c(c) {}
  std::string name() const override {
    return "Triangle";
  }
  void calc_area() override {
    double s = (a + b + c) / 2;
    area = sqrt(s * (s-a) * (s-b) * (s-c));
  }
  void calc_perimeter() override {
    perimeter = a + b + c;
  }
};

int main()
{
  using xchen::selection_sort;
  using xchen::print_array;

  // int a[] = {64, 25, 12, 23, 11};
  // double a[] = {64.1, 25.2, 12.3, 23.4, 11.5};
  // std::string a[] = {"hello", "world", "zju", "boys", "girls"};
  Student a[] = {{2011,"Newton"}, {2002,"Gauss"}, {2133,"Euler"}, {2076,"Riemann"}, {2054,"Mozi"}};
  int n = sizeof(a)/sizeof(a[0]);
  selection_sort(a, n);
  print_array(a, n);


  Shape* arr[] = {new Rectangle(2,3), new Rectangle(5,5), new Circle(3), new Triangle(2,5,4)};
  n = sizeof(arr)/sizeof(arr[0]);
  for (Shape* s: arr)
  {
    s->calc_area();
    s->calc_perimeter();
  }

  selection_sort(arr, n, less_shape_area);
  print_array(arr, n);
  selection_sort(arr, n, less_shape_perimeter);
  print_array(arr, n);
  selection_sort(arr, n, greater_shape_area);
  print_array(arr, n);
  selection_sort(arr, n, [](Shape* s1, Shape* s2){ return s1->get_perimeter() > s2->get_perimeter(); });
  print_array(arr, n);

  for (Shape* s : arr)
    delete s;

  return 0;
}
