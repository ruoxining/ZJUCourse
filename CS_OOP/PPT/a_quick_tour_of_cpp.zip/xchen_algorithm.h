#pragma once

namespace xchen {

template<typename T>
int min_element(T arr[], int i, int n)
{
  int min_idx = i;
  for (int j = i + 1; j < n; ++j)
  {
    if (arr[j] < arr[min_idx])
      min_idx = j;
  }
  return min_idx;
}

template<typename T, typename Compare>
int min_element(T arr[], int i, int n, Compare comp)
{
  int min_idx = i;
  for (int j = i + 1; j < n; ++j)
  {
    if (comp(arr[j], arr[min_idx]))
      min_idx = j;
  }
  return min_idx;
}

template<typename T>
void swap(T& a, T& b)
{
  T tmp = a;
  a = b;
  b = tmp;
}

template<typename T>
void selection_sort(T arr[], int n)
{
  for (int i = 0; i < n - 1; ++i)
  {
    int min_idx = min_element(arr, i, n);
    if (min_idx != i)
      swap(arr[min_idx], arr[i]);
  }
}

template<typename T, typename Compare>
void selection_sort(T arr[], int n, Compare comp)
{
  for (int i = 0; i < n - 1; ++i)
  {
    int min_idx = min_element(arr, i, n, comp);
    if (min_idx != i)
      swap(arr[min_idx], arr[i]);
  }
}

template<typename T>
void print_array(T arr[], int n)
{
  for (int i = 0; i < n; ++i)
    std::cout << arr[i] << ' ';
  std::cout << '\n';
}

template<typename T>
void print_array(T* arr[], int n)
{
  for (int i = 0; i < n; ++i)
    std::cout << *arr[i] << ' ';
  std::cout << '\n';
}

} // end of namespace xchen
