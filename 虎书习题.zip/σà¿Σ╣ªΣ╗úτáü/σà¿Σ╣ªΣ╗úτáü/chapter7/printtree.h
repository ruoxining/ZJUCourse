/* function prototype from printtree.c */
void printStmList (FILE *out, T_stmList stmList) ;

